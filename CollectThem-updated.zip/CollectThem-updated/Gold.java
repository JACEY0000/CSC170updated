import greenfoot.*; 

public class Gold extends Actor
{
    public void act()
    
    {
        


    }
        
    }


